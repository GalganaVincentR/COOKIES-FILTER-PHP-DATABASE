function showDetails(memberId) {
    const detailsDiv = document.getElementById(`details-${memberId}`);
    if (detailsDiv.style.display === 'none' || detailsDiv.style.display === '') {
        detailsDiv.style.display = 'block';
    } else {
        detailsDiv.style.display = 'none';
    }
}